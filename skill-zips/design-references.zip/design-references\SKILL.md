---
name: design-references
description: Gather real, current design references before designing or building any website, landing page, app screen, dashboard, portfolio or brand page. Picks the right inspiration galleries (Awwwards, Godly, Mobbin, Land-book, etc.), launches Sonnet/Haiku scout subagents at medium effort to extract concrete patterns, then turns them into a design brief. Use when the user asks for inspiration, references, "best designs", "what do top sites do", or before starting any visual build so the result has taste instead of generic defaults.
---

# Design references

Goal: ground every design in what excellent, current work actually looks like, then hand a short brief to the build skills (`design-taste-frontend`, `impeccable`, `frontend-design`, `ui-ux-pro-max`).

## Workflow

1. **Classify the project**: marketing site, SaaS landing, portfolio/studio, ecommerce, mobile app, dashboard, editorial, brand/identity, or motion-heavy experience.
2. **Pick 3-5 galleries** from `references/sites.md` that match. Mix one "best of best" source (Awwwards, FWA, CSS Design Awards) with one "common and practical" source (Land-book, SaaS Landing Page, Mobbin) so the brief is ambitious but buildable.
3. **Launch scout subagents in parallel**, one per gallery (or per category page). Use the `Agent` tool:
   - `subagent_type: "design-reference-scout"` if that agent exists, otherwise `general-purpose`
   - `model: "sonnet"` for visual analysis and anything needing judgment; `model: "haiku"` only for plain list scraping
   - `effort: "medium"`
   - Prompt = the gallery category URL, the project type, and the extraction template below. Ask for a short report, not page dumps.
4. **Synthesize** the reports into one brief (template below). Drop anything that conflicts with the user's brand or audience.
5. **Build with the brief**, then check the result against it and against `accessibility` and `web-design-guidelines`.

## Extraction template (give this to each scout)

For 4-6 standout sites on the page, report each as:
- Name, URL, why it is good in one sentence
- Layout: grid, density, section rhythm, hero structure
- Type: heading and body fonts (inspect CSS/computed styles), scale, weight, tracking
- Color: background, text, accent hex values, light or dark
- Motion: what animates, trigger (scroll, hover, load), approximate timing and easing
- Signature move: the one idea that makes it memorable
- Stack hints: framework, WebGL/Three.js, GSAP, Lenis, Webflow, etc.
- Cost: anything heavy or inaccessible (autoplay video, scroll hijack, low contrast)

Scouts read pages with `get_page_text`/`read_page` first and screenshots only when needed. Many galleries block plain HTTP fetches (403/429); use the browser tools for those. Scouts must not sign in, download files, or submit forms.

## Output: design brief

- Direction in two sentences (mood, audience)
- 3-5 references with the specific thing borrowed from each
- Type pairing, palette (hex), spacing/grid rule
- 2 signature moments and the motion spec for each
- What to avoid (generic hero, gradient blobs, three-card feature grid, stock copy)

## Rules

- Borrow principles and techniques. Never copy a site's layout wholesale, its assets, copy, illustrations or code.
- Cite the source URL for every reference so the user can open it.
- Report what was actually seen. If a page failed to load, say so; do not reconstruct from memory.
- Copy in the build goes through `humanizer`.
