# Design gallery catalogue

Access notes come from a plain HTTP probe on 2026-11-25: OK = loads, BROWSER = blocked or throttled for plain fetch (use the browser tools), UNSURE = did not respond. Descriptions are from general knowledge of each site; confirm on first visit.

## Best of the best (award-level, experimental)
| Site | URL | Use for | Access |
|---|---|---|---|
| Awwwards | https://www.awwwards.com/websites/sites_of_the_day/ | Daily winners; filter by tech tag (WebGL, Three.js, transitions, storytelling) and winner category | OK |
| FWA | https://thefwa.com | Long-running award for experimental, motion-heavy work | OK |
| CSS Design Awards | https://www.cssdesignawards.com | Winners with strong front-end craft | OK |
| Godly | https://godly.website | Curated astonishing web design, strong taste filter | UNSURE |
| Siteinspire | https://www.siteinspire.com | Clean, editorial, typographic sites | BROWSER (429) |
| Httpster | https://httpster.net | Bold, offbeat, brutalist-leaning sites | OK |
| Minimal Gallery | https://minimal.gallery | Restrained, minimal sites | OK |
| Admire the Web | https://www.admiretheweb.com | Curated modern sites | OK |
| Hover States | https://www.hoverstates.com | Interaction and hover design | OK |

## Common and practical (landing pages, SaaS, product)
| Site | URL | Use for | Access |
|---|---|---|---|
| Land-book | https://land-book.com | Huge landing page library, filter by category/style | BROWSER (403) |
| Lapa Ninja | https://www.lapa.ninja | Landing pages by category, plus UI kits | BROWSER (403) |
| SaaS Landing Page | https://saaslandingpage.com | SaaS structure, pricing, hero patterns | OK |
| Landingfolio | https://www.landingfolio.com | Landing pages and components | OK |
| One Page Love | https://onepagelove.com | One-page sites, templates | OK |
| Landingpage.fyi | https://www.landingpage.fyi | Landing page examples | OK |
| Webdesign Inspiration | https://www.webdesign-inspiration.com | General gallery | OK |

## App and product UI (mobile, dashboards, flows)
| Site | URL | Use for | Access |
|---|---|---|---|
| Mobbin | https://mobbin.com | Real app screens and full flows (much is paywalled) | OK |
| Screenlane | https://screenlane.com | Mobile and web UI patterns | OK |
| Pttrns | https://www.pttrns.com | Mobile UI patterns | OK |
| Refero | https://refero.design | Searchable library of real product screens and flows | OK |
| Collect UI | https://www.collectui.com | Component-level Dribbble picks (forms, cards, pricing) | OK |
| UI Movement | https://uimovement.com | Animated UI components | OK |
| Daily UI | https://www.dailyui.co | Challenge prompts and component ideas | OK |
| Curated Design | https://www.curated.design | Link directory of galleries and resources | OK |

## Designer portfolios and visual mood
| Site | URL | Use for | Access |
|---|---|---|---|
| Dribbble | https://dribbble.com | Visual direction, UI shots (shots are not shipped products) | OK |
| Behance | https://www.behance.net | Full case studies, brand and identity work | BROWSER (403) |
| Savee | https://savee.it | Mood boards, art direction | OK |
| Are.na | https://www.are.na | Curated channels from designers | OK |
| Designspiration | https://www.designspiration.com | Visual mood, color, layout | OK |
| Pinterest | https://www.pinterest.com | Broad mood boards (login wall, low signal for web) | OK |

## Typography and layers
| Site | URL | Use for | Access |
|---|---|---|---|
| Typewolf | https://www.typewolf.com | Font pairings and what top sites use | OK |
| Fonts In Use | https://fontsinuse.com | Real-world type usage with context | OK |
| Layers | https://www.layers.to | Design resources and templates | OK |

## Picking sources by project
- Studio/portfolio or motion-heavy: Awwwards (WebGL, transitions), FWA, Godly, Httpster
- SaaS/product marketing: SaaS Landing Page, Land-book, Landingfolio, Refero, then Awwwards for one standout
- Ecommerce: Awwwards winner category "ecommerce", Siteinspire, Land-book
- Mobile app: Mobbin, Screenlane, Pttrns, Refero
- Dashboard/admin: Refero, Mobbin (web), Collect UI
- Editorial/brand: Siteinspire, Minimal Gallery, Typewolf, Fonts In Use
